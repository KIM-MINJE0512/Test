import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Polyline, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import axios from 'axios';
import { Container, Row, Col, Card, Spinner } from 'react-bootstrap';
import L from 'leaflet';

// 커스텀 마커 아이콘 설정
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png'),
  iconUrl: require('leaflet/dist/images/marker-icon.png'),
  shadowUrl: require('leaflet/dist/images/marker-shadow.png'),
});

// Timestamp를 형식화하는 함수
const formatTimestamp = (timestamp) => {
  const date = new Date(Number(timestamp) * 1000);
  return date.toLocaleString('ko-KR', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
};

const Mqtt = () => {
  const [locations, setLocations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');

  // 데이터 갱신 함수
  const fetchLocations = () => {
    const email = localStorage.getItem('customerEmail');
    if (email) {
      axios.get(`http://localhost:8080/api/location/user?email=${email}`)
        .then((response) => {
          setLocations(response.data);
          setMessage(email);
          setLoading(false);
        })
        .catch((error) => {
          console.error('Error fetching location data:', error);
          setMessage('Server error occurred');
          setLoading(false);
        });
    } else {
      setMessage('로그인이 필요합니다.');
    }
  };

  // 1분마다 데이터 갱신
  useEffect(() => {
    fetchLocations(); // 초기 데이터 로드
    const interval = setInterval(fetchLocations, 60000); // 1분마다 호출
    return () => clearInterval(interval); // 컴포넌트 언마운트 시 정리
  }, []);

  // 좌표 배열을 지도에 표시하기 위한 Polyline 경로
  const coordinates = locations.map((loc) => [loc.latitude, loc.longitude]);

  return (
    <Container fluid className="mt-4">
      <Row className="justify-content-center">
        <Col xs={12} md={10}>
          <Card className="shadow border-0">
            <Card.Header as="h5" className="bg-primary text-white text-center">
              GPS 경로 추적
            </Card.Header>
            <Card.Body>
              {loading ? (
                <div className="text-center">
                  <Spinner animation="border" variant="primary" />
                  <p>데이터를 불러오는 중...</p>
                </div>
              ) : (
                <div className="map-container" style={{ height: '500px', width: '100%' }}>
                  <MapContainer
                    center={coordinates.length > 0 ? coordinates[0] : [37.4637, 126.6812]}
                    zoom={15}
                    scrollWheelZoom={false}
                    style={{ height: '100%', width: '100%' }}
                  >
                    <TileLayer
                      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                      attribution="&copy; <a href='https://www.openstreetmap.org/copyright'>OpenStreetMap</a> contributors"
                    />
                    {coordinates.length > 0 && <Polyline positions={coordinates} color="blue" />}
                    {locations.map((location, idx) => (
                      <Marker key={idx} position={[location.latitude, location.longitude]}>
                        <Popup>
                          <strong>Timestamp:</strong> {formatTimestamp(location.timestamp)}
                        </Popup>
                      </Marker>
                    ))}
                  </MapContainer>
                </div>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>
      <Row className="mt-3 justify-content-center">
        <Col xs={12} className="text-center">
          <p>{message}</p>
        </Col>
      </Row>
    </Container>
  );
};

export default Mqtt;
