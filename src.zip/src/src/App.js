import React from 'react';
import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import Navbar from './Navbar';
import Home from './Home';
import SignUp from './SignUp';
import Login from './Login';
import Mqtt from './Mqtt';


function App() {
  return (
    <Router>
      <ConditionalNavbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/login" element={<Login />} />
        <Route path="/mqtt" element={<Mqtt />} />
      </Routes>
    </Router>
  );
}

// 조건부 Navbar 컴포넌트
function ConditionalNavbar() {
  const location = useLocation();

  if (location.pathname === '/mqtt') {
    return <Navbar />;
  } else {
    return <Navbar />;
  }
}

export default App;
