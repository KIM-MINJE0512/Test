import React from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import introImage from './assets/old-people.png'; // 경로 추적 지도 이미지 경로 (로컬 이미지 또는 URL)
import signupImage from './assets/signuup.png';
import mapImage from './assets/trace.png';

function Home() {
  return (
    <Container className="mt-5">
      <h1 className="text-center mb-4">Welcome to Elderly Safety System</h1>

      <Row>
        {/* 첫 번째 카드 - 시스템 소개 */}
        <Col md={6} className="mb-4">
          <Card>
            <Card.Img variant="top" src={introImage} alt="System Overview" />
            <Card.Body>
              <Card.Title>Safety System Overview</Card.Title>
              <Card.Text>
                노약자 보호를 위한 실시간 경로 추적 시스템을 통해 안전한 이동을 보장합니다.
                사용자가 실시간 위치를 쉽게 파악하고, 미아 방지를 위한 최신 기술을 제공합니다.
              </Card.Text>
              <Link to="/login">
                <Button variant="primary">로그인</Button>
              </Link>
            </Card.Body>
          </Card>
        </Col>

        {/* 두 번째 카드 - 경로 추적 Map */}
        <Col md={6} className="mb-4">
          <Card>
            <Card.Img variant="top" src={mapImage} alt="Path Tracking Map" />
            <Card.Body>
              <Card.Title>경로 추적 Map</Card.Title>
              <Card.Text>
                노약자의 실시간 이동 경로를 지도에서 확인하세요. 시스템을 통해 위치를 모니터링하여 
                안전한 이동을 보장하고, 예상치 못한 상황을 미연에 방지할 수 있습니다.
              </Card.Text>
              <Link to="/mqtt">
                <Button variant="secondary">지도 보기</Button>
              </Link>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {/* 세 번째 카드 - 회원가입 안내 */}
      <Row>
        <Col md={12} className="text-center">
          <Card className="mb-4">
            <Card.Body>
              <Card.Title>회원가입</Card.Title>
              <Card.Text>
                아직 회원이 아니신가요? 노약자 보호 시스템에 가입하고, 경로 추적 및 다양한 
                맞춤형 서비스를 경험해보세요.
              </Card.Text>
              <Link to="/signup">
                <Button variant="success">회원가입</Button>
              </Link>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}

export default Home;
