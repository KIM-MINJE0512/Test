import React, { useState } from 'react';
import { Container, Row, Col, Form, Button, Alert } from 'react-bootstrap';
import axios from 'axios';

function SignUp() {
  const [formData, setFormData] = useState({
    email: '',
    name: '',
    password: '',
    confirmPassword: '',
    phoneNumber: '',
    userType: ''
  });
  const [responseMessage, setResponseMessage] = useState('');
  const [messageType, setMessageType] = useState(''); // 성공/실패 메시지 스타일을 위한 상태 추가

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // 비밀번호 확인
    if (formData.password !== formData.confirmPassword) {
      setResponseMessage('비밀번호가 일치하지 않습니다.');
      setMessageType('danger');
      return;
    }

    try {
      const response = await axios.post('http://localhost:8080/api/auth/signUp', formData);
      if (response.data.result) {
        setResponseMessage(response.data.message);
        setMessageType('success');
      } else {
        setResponseMessage(response.data.message);
        setMessageType('danger');
      }
    } catch (error) {
      setResponseMessage('서버와의 통신에 실패했습니다.');
      setMessageType('danger');
    }
  };

  return (
    <Container className="mt-5">
      <Row className="justify-content-center">
        <Col md={6} lg={4}>
          <h2 className="text-center mb-4">회원가입</h2>

          {/* 응답 메시지 */}
          {responseMessage && (
            <Alert variant={messageType}>
              {responseMessage}
            </Alert>
          )}

          <Form onSubmit={handleSubmit}>
            <Form.Group controlId="formEmail" className="mb-3">
              <Form.Label>이메일</Form.Label>
              <Form.Control
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="이메일을 입력하세요"
                required
              />
            </Form.Group>

            <Form.Group controlId="formName" className="mb-3">
              <Form.Label>이름</Form.Label>
              <Form.Control
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="이름을 입력하세요"
                required
              />
            </Form.Group>

            <Form.Group controlId="formPassword" className="mb-3">
              <Form.Label>비밀번호</Form.Label>
              <Form.Control
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                placeholder="비밀번호를 입력하세요"
                required
              />
            </Form.Group>

            <Form.Group controlId="formConfirmPassword" className="mb-3">
              <Form.Label>비밀번호 확인</Form.Label>
              <Form.Control
                type="password"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
                placeholder="비밀번호를 확인하세요"
                required
              />
            </Form.Group>

            <Form.Group controlId="formPhoneNumber" className="mb-3">
              <Form.Label>전화번호</Form.Label>
              <Form.Control
                type="text"
                name="phoneNumber"
                value={formData.phoneNumber}
                onChange={handleChange}
                placeholder="전화번호를 입력하세요"
                required
              />
            </Form.Group>

            <Form.Group controlId="formUserType" className="mb-3">
              <Form.Label>사용자 유형</Form.Label>
              <Form.Control
                type="text"
                name="userType"
                value={formData.userType}
                onChange={handleChange}
                placeholder="사용자 유형을 입력하세요 (예: customer)"
                required
              />
            </Form.Group>

            <Button variant="primary" type="submit" className="w-100">
              회원가입
            </Button>
          </Form>
        </Col>
      </Row>
    </Container>
  );
}

export default SignUp;
