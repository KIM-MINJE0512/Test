import React, { useState } from 'react';
import { Button, Form, Container } from 'react-bootstrap';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Login() {
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [responseMessage, setResponseMessage] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8080/api/auth/login', formData);
      if (response.data.result) {
        localStorage.setItem('customerEmail', formData.email);
        setResponseMessage('로그인 성공');
        navigate('/');
      } else {
        setResponseMessage(response.data.message);
      }
    } catch (error) {
      setResponseMessage('로그인 실패');
    }
  };

  return (
    <Container className="mt-5">
      <h2>로그인</h2>
      <Form onSubmit={handleSubmit}>
        <Form.Group controlId="email">
          <Form.Label>이메일</Form.Label>
          <Form.Control type="email" name="email" onChange={handleChange} required />
        </Form.Group>
        <Form.Group controlId="password" className="mt-3">
          <Form.Label>비밀번호</Form.Label>
          <Form.Control type="password" name="password" onChange={handleChange} required />
        </Form.Group>
        <Button variant="primary" type="submit" className="mt-3">로그인</Button>
      </Form>
      {responseMessage && <p className="mt-3">{responseMessage}</p>}
    </Container>
  );
}

export default Login;
