import React, { useEffect, useState } from 'react';
import { Navbar, Nav, Container } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import logoImage from './assets/logo.png';

function AppNavbar() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userEmail, setUserEmail] = useState('');
  const navigate = useNavigate();

  // 로그인 상태 확인
  useEffect(() => {
    const storedEmail = localStorage.getItem('customerEmail');
    setIsLoggedIn(!!storedEmail); // 이메일이 있으면 true
    setUserEmail(storedEmail || ''); // 이메일을 상태에 저장
  }, []); // 의존성 배열을 빈 배열로 설정하여 컴포넌트가 마운트될 때만 실행

  const handleLogout = () => {
    localStorage.removeItem('customerEmail'); // 로그아웃 시 이메일 정보 제거
    setIsLoggedIn(false); // 상태 업데이트
    setUserEmail(''); // 이메일 상태 초기화
    navigate('/'); // 로그인 페이지로 리다이렉트
  };

  return (
    <Navbar bg="success" variant="dark" expand="lg" className="navbar-custom">
      <Container>
        <Navbar.Brand as={Link} to="/"> 
          <img
            src={logoImage} alt="Logo"
            style={{
              width: '50px',
              height: '50px',
              marginRight: '8px',
            }}
          />
          노종팔
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link as={Link} to="/">홈</Nav.Link>
            <Nav.Link as={Link} to="/mqtt">위치</Nav.Link>
            <Nav.Link as={Link} to="/photos">사진</Nav.Link>
            <Nav.Link as={Link} to="/tips">정보</Nav.Link>
          </Nav>
          <Nav>
            {isLoggedIn ? (
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <span style={{ color: 'white', marginRight: '10px' }}>{userEmail}</span>
                <Nav.Link onClick={handleLogout}>로그아웃</Nav.Link>
              </div>
            ) : (
              <>
                <Nav.Link as={Link} to="/signup">회원가입</Nav.Link>
                <Nav.Link as={Link} to="/login">로그인</Nav.Link>
              </>
            )}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default AppNavbar;
