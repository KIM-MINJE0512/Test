import React, { useState } from 'react';
import { Container, Button, Card } from 'react-bootstrap';

function Prevention() {
  // 상태 관리: 현재 표시할 콘텐츠를 선택
  const [activeContent, setActiveContent] = useState('method'); // 기본값: '실종 예방 방법'

  return (
    <Container className="mt-5">
      <h1 className="text-center mb-4">실종 예방</h1>

      {/* 버튼 그룹 */}
      <div className="text-center mb-4">
        <Button 
          variant={activeContent === 'method' ? 'primary' : 'outline-primary'} 
          onClick={() => setActiveContent('method')}
          className="me-2"
        >
          실종 예방 방법
        </Button>
        <Button 
          variant={activeContent === 'food' ? 'primary' : 'outline-primary'} 
          onClick={() => setActiveContent('food')}
        >
          예방에 좋은 음식
        </Button>
      </div>

      {/* 콘텐츠 표시 */}
      {activeContent === 'method' && (
        <Card>
          <Card.Body>
            <Card.Title>실종 예방 방법</Card.Title>
            <Card.Text>
              - GPS 추적기를 항상 휴대하도록 합니다.<br />
              - 사람이 많은 장소에서는 보호자가 동반합니다.<br />
              - 긴급 상황 시 대처 방안을 미리 설정해 두세요.<br />
              - 실종을 대비한 사진과 연락처를 최신 상태로 유지하세요.<br />
            </Card.Text>
          </Card.Body>
        </Card>
      )}

      {activeContent === 'food' && (
        <Card>
          <Card.Body>
            <Card.Title>예방에 좋은 음식</Card.Title>
            <Card.Text>
              - 뇌 건강에 좋은 음식: 견과류, 생선, 블루베리.<br />
              - 비타민이 풍부한 채소: 브로콜리, 시금치.<br />
              - 오메가-3가 풍부한 음식: 연어, 고등어.<br />
              - 충분한 수분 섭취: 물, 허브티.<br />
            </Card.Text>
          </Card.Body>
        </Card>
      )}
    </Container>
  );
}

export default Prevention;
