import React, { useState } from 'react';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import loginImage from './assets/signuup.png';

function LoginPage() {
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [responseMessage, setResponseMessage] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8080/api/auth/login', formData);
      if (response.data.result) {
        localStorage.setItem('customerEmail', formData.email);
        setResponseMessage('로그인 성공');
        navigate('/');
      } else {
        setResponseMessage(response.data.message);
      }
    } catch (error) {
      setResponseMessage('로그인 실패: 서버와 통신할 수 없습니다.');
    }
  };

  return (
    <Container className="d-flex flex-column align-items-center justify-content-center" style={{ minHeight: '100vh' }}>
      {/* 이미지 섹션 */}
      <Row className="mb-4">
        <Col className="d-flex justify-content-center">
          <img
            src={loginImage}
            alt="Login Illustration"
            style={{
              width: '300px',
              height: 'auto',
            }}
          />
        </Col>
      </Row>

      {/* 로그인 폼 */}
      <Row className="w-100" style={{ maxWidth: '400px' }}>
        <Col>
          <h2 className="text-center mb-4">Login</h2>
          <Form onSubmit={handleSubmit}>
            <Form.Group className="mb-3" controlId="formBasicEmail">
              <Form.Control
                type="email"
                name="email"
                placeholder="Email"
                onChange={handleChange}
                required
                style={{
                  border: '2px solid black',
                  borderRadius: '4px',
                  padding: '10px',
                  fontSize: '16px',
                }}
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicPassword">
              <Form.Control
                type="password"
                name="password"
                placeholder="Password"
                onChange={handleChange}
                required
                style={{
                  border: '2px solid black',
                  borderRadius: '4px',
                  padding: '10px',
                  fontSize: '16px',
                }}
              />
            </Form.Group>

            <Button
              variant="primary"
              type="submit"
              className="w-100"
              style={{
                backgroundColor: 'white',
                border: '2px solid #00aaff',
                color: 'black',
                fontWeight: 'bold',
                padding: '10px',
                fontSize: '16px',
              }}
            >
              로그인
            </Button>
          </Form>

          {/* 응답 메시지 */}
          {responseMessage && <p className="text-center mt-3">{responseMessage}</p>}
        </Col>
      </Row>
    </Container>
  );
}

export default LoginPage;
