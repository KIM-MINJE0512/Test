import React, { useState } from 'react';
import { Container, Button, Card } from 'react-bootstrap';
import tipIcon from './assets/tip.png'; // tip.png 파일 경로를 설정하세요.
import './PreventionTips.css'; // 추가한 CSS 파일

function PreventionTips() {
  const [activeContent, setActiveContent] = useState('method');

  return (
    <Container className="mt-5">
      <Card className="custom-card">
        <Card.Body>
          <div className="text-center mb-4">
            <img 
              src={tipIcon} 
              alt="Tip Icon" 
              className="tip-image"
            />
          </div>

          <div className="d-flex flex-column flex-md-row align-items-start">
            <div className="me-0 me-md-4 d-flex flex-column">
              <Button 
                variant="warning" 
                className={`mb-2 custom-button ${activeContent === 'method' ? 'active' : ''} animate-button`}
                onClick={() => setActiveContent('method')}
              >
                실종 예방 방법
              </Button>
              <Button 
                variant="warning" 
                className={`mb-2 custom-button ${activeContent === 'food' ? 'active' : ''} animate-button`}
                onClick={() => setActiveContent('food')}
              >
                치매에 좋은 음식
              </Button>
              <Button 
                variant="warning" 
                className={`mb-2 custom-button ${activeContent === 'exercise' ? 'active' : ''} animate-button`}
                onClick={() => setActiveContent('exercise')}
              >
                운동의 중요성
              </Button>
              <Button 
                variant="warning" 
                className={`custom-button ${activeContent === 'sleep' ? 'active' : ''} animate-button`}
                onClick={() => setActiveContent('sleep')}
              >
                충분한 수면
              </Button>
            </div>

            <div className="flex-grow-1 mt-3 mt-md-0">
              {activeContent === 'method' && (
                <div>
                  <Card.Title className="card-title">실종 예방 방법</Card.Title>
                  <Card.Text className="card-text">
                    - 노.종.팔을 항상 휴대하도록 합니다.<br />
                    - 사람이 많은 장소에서는 보호자가 동반합니다.<br />
                    - 긴급 상황 시 대처 방안을 미리 설정해 두세요.<br />
                    - 실종을 대비한 사진과 연락처를 최신 상태로 유지하세요.<br />
                  </Card.Text>
                </div>
              )}

              {activeContent === 'food' && (
                <div>
                  <Card.Title className="card-title">치매에 좋은 음식</Card.Title>
                  <Card.Text className="card-text">
                    - 뇌 건강에 좋은 음식: 견과류, 생선, 블루베리.<br />
                    - 비타민이 풍부한 채소: 브로콜리, 시금치.<br />
                    - 오메가-3가 풍부한 음식: 연어, 고등어.<br />
                    - 충분한 수분 섭취: 물, 허브티.<br />
                  </Card.Text>
                </div>
              )}

              {activeContent === 'exercise' && (
                <div>
                  <Card.Title className="card-title">운동의 중요성</Card.Title>
                  <Card.Text className="card-text">
                    - 규칙적인 운동은 신체 건강을 유지하는 데 필수적입니다.<br />
                    - 심혈관 건강을 개선하고 스트레스를 줄여줍니다.<br />
                    - 근육과 뼈를 강화하여 부상을 예방합니다.<br />
                  </Card.Text>
                </div>
              )}

              {activeContent === 'sleep' && (
                <div>
                  <Card.Title className="card-title">충분한 수면</Card.Title>
                  <Card.Text className="card-text">
                    - 충분한 수면은 정신적, 신체적 건강에 중요합니다.<br />
                    - 수면 부족은 집중력 저하와 면역력 약화를 초래할 수 있습니다.<br />
                    - 규칙적인 수면 패턴을 유지하는 것이 좋습니다.<br />
                  </Card.Text>
                </div>
              )}
            </div>
          </div>
        </Card.Body>
      </Card>
    </Container>
  );
}

export default PreventionTips;
