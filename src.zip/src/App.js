import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import Navbar from './Navbar';
import Home from './Home';
import SignUp from './SignUp';
import Login from './Login';
import Mqtt from './Mqtt';
import PeopleImage from './PeopleImage';
import Tips from './Tips';  
import 'bootstrap/dist/css/bootstrap.min.css';



function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false); // 로그인 상태 관리

  return (
    <Router>
      <ConditionalNavbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/signup" element={<SignUp />} />
        <Route
          path="/login"
          element={<Login onLoginSuccess={() => setIsLoggedIn(true)} />} // 로그인 성공 처리
        />
        <Route path="/mqtt" element={<Mqtt />} />
        <Route
          path="/photos"
          element={<PeopleImage isLoggedIn={isLoggedIn} />} // 로그인 상태 전달
        />
        <Route path="/tips" element={<Tips />} />
      </Routes>
    </Router>
  );
}

// 조건부 Navbar 컴포넌트
function ConditionalNavbar() {
  const location = useLocation();

  if (location.pathname === '/mqtt') {
    return <Navbar />;
  } else {
    return <Navbar />;
  }
}

export default App;
