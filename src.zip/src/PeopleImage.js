import React, { useState, useRef, useEffect } from "react";
import uploadIcon from "./assets/upload_logo.png";

function StylishFileUpload() {
  const [images, setImages] = useState([]);
  const [selectedImage, setSelectedImage] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const realUploadRef = useRef(null);

  // 로그인 상태 확인
  useEffect(() => {
    const email = localStorage.getItem("customerEmail");
    if (email) {
      setIsLoggedIn(true);
    } else {
      setIsLoggedIn(false);
    }
  }, []);

  const handleFileChange = async (e) => {
    if (!isLoggedIn) {
      alert("로그인 후 업로드가 가능합니다.");
      return;
    }

    const files = Array.from(e.target.files);

    if (files.length > 6) {
      alert("이미지는 최대 6개까지 업로드 가능합니다.");
      return;
    }

    const validImages = files.filter((file) => file.type.startsWith("image/"));

    try {
      const readers = validImages.map((file) => {
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result);
          reader.readAsDataURL(file);
        });
      });

      const newImages = await Promise.all(readers);
      setImages((prevImages) => [...prevImages, ...newImages]);
    } catch (error) {
      console.error("파일 읽기 중 오류:", error);
    }
  };

  const handleUploadClick = () => {
    if (!isLoggedIn) {
      alert("로그인 후 업로드가 가능합니다.");
      return;
    }
    realUploadRef.current.click();
  };

  return (
    <div style={{ padding: "20px", fontFamily: "'Arial', sans-serif" }}>
      {isLoggedIn ? (
        <>
          <div
            style={{
              border: "2px dashed #d3d3d3",
              borderRadius: "10px",
              width: "100%",
              height: "200px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              backgroundColor: "#f9f9f9",
            }}
            onClick={handleUploadClick}
          >
            <input
              type="file"
              ref={realUploadRef}
              style={{ display: "none" }}
              accept="image/*"
              multiple
              onChange={handleFileChange}
            />
            <div style={{ textAlign: "center", color: "#a3a3a3" }}>
              <img
                src={uploadIcon}
                alt="Upload Icon"
                style={{
                  marginBottom: "10px",
                  width: "70px",
                  height: "70px",
                  animation: "shake 1s infinite",
                }}
              />
              <p style={{ fontSize: "16px", margin: "0" }}>
                <strong>사진을 업로드하세요! 드래그 or 파일선택</strong>
              </p>
            </div>
          </div>

          {/* 업로드된 이미지 목록 */}
          <div
            style={{
              display: "flex",
              flexWrap: "wrap",
              gap: "15px",
              marginTop: "20px",
              justifyContent: "center",
            }}
          >
            {images.map((src, index) => (
              <div
                key={index}
                style={{
                  position: "relative",
                  width: "150px",
                  height: "150px",
                  borderRadius: "8px",
                  overflow: "hidden",
                  boxShadow: "0px 4px 6px rgba(0,0,0,0.1)",
                }}
              >
                <img
                  src={src}
                  alt={`Uploaded ${index}`} // 수정된 부분
                  style={{
                    width: "100%",
                    height: "100%",
                    objectFit: "cover",
                    cursor: "pointer",
                  }}
                  onClick={() => setSelectedImage(src)}
                />
              </div>
            ))}
          </div>
        </>
      ) : (
        <p style={{ textAlign: "center", color: "#888" }}>
          로그인 후 사진 업로드가 가능합니다.
        </p>
      )}
    </div>
  );
}

export default StylishFileUpload;
