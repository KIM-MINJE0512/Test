import React, { useEffect, useState } from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import mapImage from './assets/trace.png';
import LoginImage from './assets/signuup.png';
import headerImage from './assets/header.jpg';

function Home() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const navigate = useNavigate();

  // 로컬 스토리지에서 로그인 상태 확인
  useEffect(() => {
    const storedEmail = localStorage.getItem('customerEmail');
    setIsLoggedIn(!!storedEmail); // 이메일이 있으면 true, 없으면 false
  }, []);

  // 로그아웃 핸들러
  const handleLogout = () => {
    localStorage.removeItem('customerEmail'); // 로그인 정보 제거
    setIsLoggedIn(false); // 상태 업데이트
    navigate('/'); // 홈으로 리다이렉트
  };

  return (
    <>
      {/* 헤더 섹션 */}
      <Container fluid className="px-0">
        <div style={{ position: 'relative', width: '100%' }}>
          <img
            src={headerImage}
            alt="노종팔 메인 이미지"
            style={{
              width: '100%',
              height: '300px', // 세로폭 줄이기
              objectFit: 'cover', // 이미지 비율 유지하며 영역 채우기
              display: 'block',
            }}
          />
          <h1
            style={{
              fontFamily: 'SDSwagger, sans-serif',
              position: 'absolute',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              color: 'white',
              textShadow: '2px 2px 5px rgba(0, 0, 0, 0.7)',
              fontSize: '4rem',
            }}
          >
            노인을 지키는 노종팔
          </h1>
        </div>
      </Container>

      {/* 카드 섹션 */}
      <Container className="mt-4">
        <Row>
          {/* 지도 보기 카드 */}
          <Col md={6} className="mb-4 d-flex justify-content-center">
            <Card style={{ width: '90%', maxWidth: '300px' }}>
              <Card.Img variant="top" src={mapImage} alt="Path Tracking Map" />
              <Card.Body>
                <Card.Title>현재 위치 보기</Card.Title>
                <Card.Text style={{ fontSize: '0.9rem' }}>
                  {isLoggedIn ? "지도를 이용하세요." : "로그인 이후 이용 가능합니다."}
                </Card.Text>
                {isLoggedIn ? (
                  <Link to="/mqtt">
                    <Button variant="secondary">지도 보기</Button>
                  </Link>
                ) : (
                  <Link to="/login">
                    <Button variant="secondary">로그인</Button>
                  </Link>
                )}
              </Card.Body>
            </Card>
          </Col>

          {/* 로그인/로그아웃 카드 */}
          <Col md={6} className="mb-4 d-flex justify-content-center">
            <Card style={{ width: '90%', maxWidth: '300px' }}>
              <Card.Img variant="center" src={LoginImage} alt="Path Tracking Map" />
              <Card.Body>
                <Card.Title>{isLoggedIn ? "로그아웃" : "로그인"}</Card.Title>
                <Card.Text style={{ fontSize: '0.9rem' }}>
                  {isLoggedIn
                    ? "현재 로그인 상태입니다."
                    : "노종팔에 가입, 로그인하세요!"}
                </Card.Text>
                {isLoggedIn ? (
                  <Button variant="danger" onClick={handleLogout}>
                    로그아웃
                  </Button>
                ) : (
                  <Link to="/login">
                    <Button variant="secondary">로그인</Button>
                  </Link>
                )}
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </>
  );
}

export default Home;
